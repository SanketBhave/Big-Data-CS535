import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import java.util.HashMap;

public class TwitterAPI {
    public static void main(String[] args) {
        ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
        configurationBuilder.setOAuthConsumerKey("edJRHa73uTWntNXk5fwHjeR3s")
                .setOAuthConsumerSecret("Mls8vJbjgJEk57OdwaSm55xQR32sHaVvPafUxDEH8OyKxHT2k6")
                .setOAuthAccessToken("1497063044576276483-2hd72iWln9kGmod3Yk5UHpB3pDbzjz")
                .setOAuthAccessTokenSecret("mV7HOfN9F9npqSHBnc88aSZ1iUbFvVHcwr7S7qcoReiae");
        TwitterStream twitterStream = new TwitterStreamFactory(
                configurationBuilder.setJSONStoreEnabled(true).build())
                .getInstance();
        StatusListener listener = new StatusListener(){

            @Override
            public void onException(Exception e) {
                e.printStackTrace();

            }

            @Override
            public void onStatus(Status status) {
                HashMap<String, Integer> popular_hashtags = new HashMap<String, Integer>();
               HashtagEntity hashtags[] = status.getHashtagEntities();

               for(HashtagEntity hashtagEntity: hashtags) {
                   System.out.println(hashtagEntity.getText());
               }

            }

            @Override
            public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {

            }

            @Override
            public void onTrackLimitationNotice(int i) {

            }

            @Override
            public void onScrubGeo(long l, long l1) {

            }

            @Override
            public void onStallWarning(StallWarning stallWarning) {

            }
        };
        twitterStream.addListener(listener);
       /// FilterQuery filterQuery = new FilterQuery();
//        String place = "place_country:US";
//        filterQuery.language("english");
        twitterStream.sample();
    }

}
