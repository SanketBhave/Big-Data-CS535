import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountBolt extends BaseRichBolt {
    private HashMap<String, Integer> count_table;
    private OutputCollector collector;
    long initTime;
    @Override
    public void prepare(Map<String, Object> map, TopologyContext topologyContext, OutputCollector outputCollector) {
            this.collector = outputCollector;
            initTime = System.currentTimeMillis();
            count_table = new HashMap<>();

    }

    @Override
    public void execute(Tuple tuple) {
        long currentTime = System.currentTimeMillis();
        String hashtag = tuple.getStringByField("hashtag");
        int count = count_table.getOrDefault(hashtag, 0);
        count_table.put(hashtag, count+1);
        if(currentTime-initTime >= 10000) {
            this.collector.emit(new Values(hashtag, count_table.get(hashtag)));
            initTime = currentTime;
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
            outputFieldsDeclarer.declare(new Fields("hashtag", "count"));
    }

    @Override
    public void cleanup(){
    }
}
