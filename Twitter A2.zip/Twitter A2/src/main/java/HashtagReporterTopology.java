import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.AlreadyAliveException;
import org.apache.storm.generated.AuthorizationException;
import org.apache.storm.generated.InvalidTopologyException;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.utils.Time;

import java.util.List;
import java.util.Map;

public class HashtagReporterTopology {

    private static final String TWITTER_SPOUT_ID = "twitter_spout";
    private static final String COUNT_BOLT_ID = "count_bolt";
    private static final String REPORT_BOLT_ID = "report_bolt";
    private static final String TOPOLOGY_NAME = "twitter";

    public static void main(String[] args) throws Exception {
        TwitterSpout twitterSpout = new TwitterSpout();
        CountBolt countBolt = new CountBolt();
        ReportBolt reportBolt = new ReportBolt();

        TopologyBuilder topologyBuilder = new TopologyBuilder();
        topologyBuilder.setSpout(TWITTER_SPOUT_ID, twitterSpout);
        topologyBuilder.setBolt(COUNT_BOLT_ID, countBolt).allGrouping(TWITTER_SPOUT_ID);
        topologyBuilder.setBolt(REPORT_BOLT_ID, reportBolt).allGrouping(COUNT_BOLT_ID);

        Config config = new Config();
//        StormSubmitter.submitTopology(TOPOLOGY_NAME, config, topologyBuilder.createTopology());
//        Thread.sleep(15000);

        LocalCluster localCluster = new LocalCluster();
        localCluster.submitTopology(TOPOLOGY_NAME, config, topologyBuilder.createTopology());
        Thread.sleep(20000);
//        localCluster.killTopology(TOPOLOGY_NAME);
//        localCluster.shutdown();

    }
}
