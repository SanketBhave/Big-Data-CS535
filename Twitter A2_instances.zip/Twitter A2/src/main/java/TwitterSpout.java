import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.Time;
import org.apache.storm.utils.Utils;
import twitter4j.*;
import twitter4j.auth.AccessToken;
import twitter4j.conf.ConfigurationBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

public class TwitterSpout extends BaseRichSpout {

    private SpoutOutputCollector collector;
    private HashtagEntity hashtags[];
    private StatusListener listener;
    private Status status;
    private ConfigurationBuilder configurationBuilder;
    private TwitterStream twitterStream;
    private LinkedBlockingQueue<Status> queue = new LinkedBlockingQueue<>();

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
            outputFieldsDeclarer.declare(new Fields("hashtag"));
    }

    @Override
    public void open(Map<String, Object> map, TopologyContext topologyContext, SpoutOutputCollector spoutOutputCollector) {
            this.collector = spoutOutputCollector;
         listener = new StatusListener(){

            @Override
            public void onException(Exception e) {
                e.printStackTrace();

            }

            @Override
            public void onStatus(Status status) {
                TwitterSpout.this.status = status;
            }

            @Override
            public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {

            }

            @Override
            public void onTrackLimitationNotice(int i) {

            }

            @Override
            public void onScrubGeo(long l, long l1) {

            }

            @Override
            public void onStallWarning(StallWarning stallWarning) {

            }
        };
//        configurationBuilder = new ConfigurationBuilder();
//        configurationBuilder.setOAuthConsumerKey("edJRHa73uTWntNXk5fwHjeR3s")
//                .setOAuthConsumerSecret("Mls8vJbjgJEk57OdwaSm55xQR32sHaVvPafUxDEH8OyKxHT2k6")
//                .setOAuthAccessToken("1497063044576276483-2hd72iWln9kGmod3Yk5UHpB3pDbzjz")
//                .setOAuthAccessTokenSecret("mV7HOfN9F9npqSHBnc88aSZ1iUbFvVHcwr7S7qcoReiae");
        twitterStream = new TwitterStreamFactory(
                new ConfigurationBuilder().setJSONStoreEnabled(true).build())
                .getInstance();
        twitterStream.setOAuthConsumer("edJRHa73uTWntNXk5fwHjeR3s", "Mls8vJbjgJEk57OdwaSm55xQR32sHaVvPafUxDEH8OyKxHT2k6");
        twitterStream.setOAuthAccessToken(new AccessToken("1497063044576276483-2hd72iWln9kGmod3Yk5UHpB3pDbzjz", "mV7HOfN9F9npqSHBnc88aSZ1iUbFvVHcwr7S7qcoReiae"));
        twitterStream.addListener(listener);
        twitterStream.sample();
    }

    @Override
    public void nextTuple() {
        if(this.status == null) {
            Utils.sleep(1000);
        }
        else {
            hashtags = this.status.getHashtagEntities();
            for (HashtagEntity hashtag : this.hashtags)
                this.collector.emit(new Values(hashtag.getText()));
//            try {
//                Time.sleepSecs(10L);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
        }
    }

    @Override
    public void close() {
        twitterStream.shutdown();
    }
}
