import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountBolt extends BaseRichBolt {
    private HashMap<String, Entry> entries = new HashMap<>();
    private List<String> toRemove = new ArrayList<>();
    private OutputCollector collector;
    private int currentBucketNumber;
    private double epsilon;
    private int bucketSize;
    private int totalCount;
    private int error;
    private long initTime;
    @Override
    public void prepare(Map<String, Object> map, TopologyContext topologyContext, OutputCollector outputCollector) {
        this.collector = outputCollector;
        this.currentBucketNumber = 1;
        this.epsilon = 0.1;
        this.bucketSize = (int) (1 / this.epsilon);
        this.totalCount = 0;
        this.error = 0;
        this.initTime = System.currentTimeMillis();

    }

    @Override
    public void execute(Tuple tuple) {
//        long currentTime = System.currentTimeMillis();
//        String hashtag = tuple.getStringByField("hashtag");
//        int count = count_table.getOrDefault(hashtag, 0);
//        count_table.put(hashtag, count+1);
//        if(currentTime-initTime >= 10000) {
//            this.collector.emit(new Values(hashtag, count_table.get(hashtag)));
//            initTime = currentTime;
//        }
        //HashMap<String, Integer> count_table  = new HashMap<>();
        long currentTime = System.currentTimeMillis();
        if (currentTime - initTime > 10000) {
            for (Map.Entry<String, Entry> entry : entries.entrySet()) {
                collector.emit(new Values(entry.getKey(), entry.getValue().getFrequency()));
            }
            initTime = currentTime;
        } else {
            runLossyCountAlgorithm(tuple);
        }
    }

    public void runLossyCountAlgorithm(Tuple tuple) {
        String tweet = tuple.getStringByField("hashtag");
        Entry entry = entries.get(tweet);

        if (entry == null) {
            entries.put(tweet, new Entry(tweet, 1, error));
        } else  {
            int currentFrequency = entry.getFrequency();
            entry.setFrequency(currentFrequency + 1);
        }

        totalCount++;

        if (totalCount % bucketSize == 0) {
            for (Map.Entry<String, Entry> eachEntry : entries.entrySet()) {
                if ((eachEntry.getValue().getFrequency() + eachEntry.getValue().getError()) <= currentBucketNumber) {
                    toRemove.add(eachEntry.getKey());
                }
            }

            //removing now to avoid concurrent modification exception
            for (String tweetToRemove : toRemove) {
                entries.remove(tweetToRemove);
            }

            //resetting list for next iteration of removals after a bucket is processed
            toRemove = new ArrayList<>();

            error++;
            currentBucketNumber++;
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
            outputFieldsDeclarer.declare(new Fields("hashtag", "count"));
    }

    @Override
    public void cleanup(){
    }
}
