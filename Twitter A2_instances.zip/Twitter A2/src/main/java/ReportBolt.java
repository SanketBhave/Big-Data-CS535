import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;
import java.util.stream.Stream;

public class ReportBolt extends BaseRichBolt {
    private File file;
    private FileWriter bfw;
    @Override
    public void prepare(Map<String, Object> map, TopologyContext topologyContext, OutputCollector outputCollector) {
            file = new File("logs.txt");
        try {
            if (!file.exists())
                file.createNewFile();
            bfw = new FileWriter(file);
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void execute(Tuple tuple) {
        HashMap<String, Integer> count_table = new HashMap<>();
        String hashtag = tuple.getStringByField("hashtag");
        int count = tuple.getIntegerByField("count");
        count_table.put(hashtag, count);
        List<Map.Entry<String, Integer>> list = new LinkedList<>(count_table.entrySet());
        Collections.sort(list, (i1, i2) -> i2.getValue().compareTo(i1.getValue()));
        HashMap<String, Integer> hashtags = new LinkedHashMap<>();
        for(Map.Entry<String, Integer> hash: list){
            hashtags.put(hash.getKey(), hash.getValue());
        }
        Timestamp timestamp = Timestamp.from(Instant.now());
        try {
            bfw.write(String.valueOf(timestamp));
            if(hashtags.keySet().size()>100) {
                bfw.write(String.valueOf(Collections.singletonList(hashtags.keySet()).subList(0, 100)));
            }
            else {
                bfw.write(String.valueOf(hashtags.keySet()));
            }
            bfw.write("\n");
            for (String key : hashtags.keySet()) {
                System.out.println(key + " : " + hashtags.get(key));
            }
            System.out.println("Wrote twitter stream");
            bfw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {

    }

    @Override
    public void cleanup() {
//        List<Map.Entry<String, Integer>> list = new LinkedList<>(count_table.entrySet());
//        Collections.sort(list, (i1, i2) -> i1.getValue().compareTo(i2.getValue()));
//        for(Map.Entry<String, Integer> hash: list){
//            hashtags.put(hash.getKey(), hash.getValue());
//        }
//        Timestamp timestamp = Timestamp.from(Instant.now());
//        try {
//            bfw.write(String.valueOf(timestamp));
//            bfw.write(String.valueOf(hashtags.keySet()));
//            for (String key : hashtags.keySet()) {
//                System.out.println(key + " : " + this.count_table.get(key));
//            }
//            System.out.println("Wrote twitter stream");
//            bfw.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
}
