import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.AlreadyAliveException;
import org.apache.storm.generated.AuthorizationException;
import org.apache.storm.generated.InvalidTopologyException;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.utils.Time;

import java.util.List;
import java.util.Map;

public class HashtagReporterTopology {

    private static final String TWITTER_SPOUT_ID = "twitter-spout";
    private static final String LOSSY_COUNT_BOLT_ID1 = "lossy-count-bolt1";
    private static final String LOSSY_COUNT_BOLT_ID2 = "lossy-count-bolt2";
    private static final String LOSSY_COUNT_BOLT_ID3 = "lossy-count-bolt3";
    private static final String LOSSY_COUNT_BOLT_ID4 = "lossy-count-bolt4";
    private static final String REPORT_BOLT_ID1 = "report-bolt1";
    private static final String REPORT_BOLT_ID2 = "report-bolt2";
    private static final String REPORT_BOLT_ID3 = "report-bolt3";
    private static final String REPORT_BOLT_ID4 = "report-bolt4";
    private static final String TOPOLOGY_NAME = "lossy-count-topology";

    public static void main(String[] args) throws Exception {
        TwitterSpout twitterSpout = new TwitterSpout();
        CountBolt lossyCountBolt1 = new CountBolt();
        CountBolt lossyCountBolt2 = new CountBolt();
        CountBolt lossyCountBolt3 = new CountBolt();
        CountBolt lossyCountBolt4 = new CountBolt();
        ReportBolt reportBolt = new ReportBolt();

        TopologyBuilder builder = new TopologyBuilder();
        builder.setSpout(TWITTER_SPOUT_ID, twitterSpout);

        builder.setBolt(LOSSY_COUNT_BOLT_ID1, lossyCountBolt1).allGrouping(TWITTER_SPOUT_ID); //groupings may be wrong
        builder.setBolt(LOSSY_COUNT_BOLT_ID2, lossyCountBolt2).allGrouping(TWITTER_SPOUT_ID);
        builder.setBolt(LOSSY_COUNT_BOLT_ID3, lossyCountBolt3).allGrouping(TWITTER_SPOUT_ID);
        builder.setBolt(LOSSY_COUNT_BOLT_ID4, lossyCountBolt4).allGrouping(TWITTER_SPOUT_ID);

        //LossyCountBolt --> ReportBolt
        builder.setBolt(REPORT_BOLT_ID1, reportBolt).allGrouping(LOSSY_COUNT_BOLT_ID1);
        builder.setBolt(REPORT_BOLT_ID2, reportBolt).allGrouping(LOSSY_COUNT_BOLT_ID2);
        builder.setBolt(REPORT_BOLT_ID3, reportBolt).allGrouping(LOSSY_COUNT_BOLT_ID3);
        builder.setBolt(REPORT_BOLT_ID4, reportBolt).allGrouping(LOSSY_COUNT_BOLT_ID4);

        Config config = new Config();
//        StormSubmitter.submitTopology(TOPOLOGY_NAME, config, topologyBuilder.createTopology());
//        Thread.sleep(15000);

        LocalCluster localCluster = new LocalCluster();
        localCluster.submitTopology(TOPOLOGY_NAME, config, builder.createTopology());
        Thread.sleep(20000);
//        localCluster.killTopology(TOPOLOGY_NAME);
//        localCluster.shutdown();

    }
}
